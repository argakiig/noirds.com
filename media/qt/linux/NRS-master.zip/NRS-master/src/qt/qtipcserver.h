#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define NoirShares-Qt message queue name
#define NoirSharesURI_QUEUE_NAME "NoirSharesURI"

void ipcScanRelay(int argc, char *argv[]);
void ipcInit(int argc, char *argv[]);

#endif // QTIPCSERVER_H
