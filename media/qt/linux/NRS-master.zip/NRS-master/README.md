NoirShares-beta (Product of NIG)

Please read the COPYING for terms of use. 

NoirShares is the first hybrid Momentum PoS/PoW crypto. Momentum algo has memory hard qualities which make reduce GPU mining advantages.

The combination momentum Proof of Work with a Proof of stake implementation serves to guard against 51% attacks. 51% attacks are situations where a person or group holds hash power equivalent to 51% or more of total network hash. This allows them to double spend their shares through a first spend then overwritting the valid block chain with their own longer block chain. Proof-of-stake block generation reduces the risk of 51% attacks because the cost of acquiring 51% of all stake would be much higher due to having to buy at least 51% of all shares in existence, that and the cost of acquiring 51% of all mining power makes the cost of attempting and attack prohibitive if not down right imposiible as the price per share will rise as people notice the demand. In some cases other miners and traders will halt sales just to wait out for the highest price, thusly making it even more complicated and nigh impossible to achieve 51% control. In a 51% stake attack the attacker's investment would be directly at risk of losing value. By contrast, with a 51% mining attack on a pure PoW implementation  the attacker would still own the mining hardware which could either be sold or used to mine a different cryptocurrency following the attack.

These measures serve to secure the network also in that users are inclined to keep their nodes online in order to generate stake. 

As proof-of-work blocks become less rewarding, coin generation becomes increasingly based on proof-of-stake block generation which in of it's own is energy efficient and requires less resources. Thus protecting the chain from attackers becomes far less expensive. 


NoirShares Features and Parameters 

Doubles as both currency and equity for the NIG group.  

80 shares per block initially

~ 5 million coins will be produced via PoW
 
5% block reward reduction every 3000 blocks 

Minumum Stake age is 7 days, full age 14 days

Tx fees are 0.01 NRS are destroyed in an attempt at aggresively countering inflation due to mining and stake

As the chain progresses and transitions to relying more on PoS blocks, it becomes highly energy efficient in comparison to pure PoW coins. This weaning of reliance on high powered machines encourages the average user to be able to have a functioning node that if used properly can be profitable. 


Launch date estimate --- 15/02/14 

More details and updates on noirbitstalk.org  

  
